package com.ashiq;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyRepo extends JpaRepository<Buy, Integer> {

}
