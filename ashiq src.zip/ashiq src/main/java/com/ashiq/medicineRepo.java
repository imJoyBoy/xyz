package com.ashiq;

import org.springframework.data.jpa.repository.JpaRepository;

public interface medicineRepo extends JpaRepository<medicine, Integer> {

}
